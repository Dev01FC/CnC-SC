namespace FirebaseSharp.Portable.Interfaces
{
    public interface IFirebaseReadonlyQuery
    {
        void Off();
        IFirebase Ref();
    }
}