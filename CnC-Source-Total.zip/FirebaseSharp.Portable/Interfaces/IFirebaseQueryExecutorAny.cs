﻿namespace FirebaseSharp.Portable.Interfaces
{
    public interface IFirebaseQueryExecutorAny : IFilterableQueryExecutor, IOrderableQueryExecutor
    {
    }
}