﻿using System.Reflection;
using System.Runtime.CompilerServices;
// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.

[assembly: AssemblyTitle("Firebase.Portable")]
[assembly: AssemblyDescription(".NET client for Firebase.io (Portable library)")]
[assembly: AssemblyProduct("Firebase.Portable")]
[assembly: AssemblyInformationalVersion("2.0.2-alpha")]
[assembly: AssemblyVersion("2.0.0.0")]
[assembly: AssemblyFileVersion("2.0.0.0")]
[assembly: InternalsVisibleTo("FirebaseSharp.Tests")]
[assembly: InternalsVisibleTo("DynamicProxyGenAssembly2")]